# goffda 0.0.5

* Initial version

# goffda 0.0.6

* Comply with _R_CLASS_MATRIX_ARRAY_=true.
* Roxygen 7.0.1.

# goffda 0.0.7

* Added option refit_lambda in `flm_test`.
* Added Lee et al. (2020) test.
* Extended applications.
* Fixes in documentation.

# goffda 0.1.0

* Support forthcoming `Rcpp`'s STRICT_R_HEADERS.
* Update bibliographical details for main reference.
* Rename `r_gof2019_flmfr` to `r_gof2021_flmfr`.

# goffda 0.1.1

* Fix in HTML version of manual.

# goffda 0.1.2

* Drop C++11 requirement to adhere to new CRAN policies.
* Drop `personList()` and `citEntry()`.
